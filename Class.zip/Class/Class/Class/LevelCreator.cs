﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.IO;

namespace Class
{
    class LevelCreator : IDisposable
    {
        private Platform[,] platforms;
        private Dictionary<string, Texture2D> platformTextures;
        Platform platform;

        public ContentManager Content
        {
            get { return content; }
        }
        ContentManager content;

        public int PlatWidth
        {
            get { return platforms.GetLength(0); }
        }

        public int PlatHeight
        {
            get { return platforms.GetLength(1); }
        }

        public LevelCreator(IServiceProvider provider, string path)
        {
            content = new ContentManager(provider, "Content");
            platformTextures = new Dictionary<string, Texture2D>();
            platformTextures.Add("Texture", Content.Load<Texture2D>("Platform Setter/Sample"));

            LoadPlatforms(path);
        }

        //Load Levels into
        private void LoadPlatforms(string path)
        {
            int numOfPlat = 0;
            List<string> lines = new List<string>();
            try
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    string line = reader.ReadLine();
                    numOfPlat = line.Length;
                    while (line != null)
                    {
                        lines.Add(line);
                        int nextLineWidth = line.Length;
                        line = reader.ReadLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file couldn't be read:");
                Console.WriteLine(e.Message);
            }
            platforms = new Platform[numOfPlat, lines.Count];

            for (int y = 0; y < PlatHeight; y++)
            {
                for (int x = 0; x < PlatWidth; x++)
                {
                    string currentRow = lines[y];
                    char charType = currentRow[x];
                    platforms[x, y] = PlatType(charType, x, y);
                }
            }
        }

        //Where the platforms are set
        private Platform PlatType(char platform, int x, int y)
        {
            switch (platform)
            {
                case '.':
                    return LoadPlatform(String.Empty, new Rectangle(), Platform.PlatformType.collidable);
                case '_':
                    return LoadPlatform("Texture", new Rectangle(0 + (x * 100), 0 + (y * 50), 100, 50), Platform.PlatformType.collidable);
                case '-':
                    return LoadPlatform("Texture", new Rectangle(0 + (x * 100), 0 + (y * 50), 50, 100), Platform.PlatformType.incollidable);
                case '|':
                    return LoadPlatform("Texture", new Rectangle(0 + (x * 50), 0 + (y * 100), 50, 100), Platform.PlatformType.verticallyCollidable);
                default:
                    throw new NotSupportedException(String.Format(
                        "Unsupported type character detected, {0}, please remove said illegal character at {1}, {2}.", platform, x, y));
            }
        }

        private Platform LoadPlatform(string texture, Rectangle rec, Platform.PlatformType platType)
        {
            return new Platform(texture, rec, platType);
        }
        //Draws Platforms
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            DrawPlatforms(spriteBatch);
        }

        private void DrawPlatforms(SpriteBatch spriteBatch)
        {
            for (int y = 0; y < PlatHeight; y++)
            {
                for (int x = 0; x < PlatWidth; x++)
                {
                    if (platformTextures.ContainsKey(platforms[x, y].PlatTex))
                    {
                        Vector2 pos = new Vector2(x, y) * platform.getSize();
                        spriteBatch.Draw(platformTextures[platforms[x, y].PlatTex], platform.PlatRec, Color.White);
                    }
                }
            }
        }

        public void Dispose()
        {
            Content.Unload();
        }
    }
}